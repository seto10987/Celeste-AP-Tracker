# Celeste-AP-Tracker
 Poptracker Pack for Celeste AP

Archipelago Celeste pack for [PopTracker](https://github.com/black-sliver/PopTracker/) with Autotracking.

PopTracker v0.23.0 or higher is recommended. 

Archipelago compatible Celeste Tracker pack, with individual level tracking for A-Side levels with Strawberries, Hearts, Level Completions, and Cassettes

Configurable Goal settings including Goal Level and Required Collectables, read directly from the Server